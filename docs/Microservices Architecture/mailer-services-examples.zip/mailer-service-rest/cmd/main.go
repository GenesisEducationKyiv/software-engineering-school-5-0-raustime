package main

import (
    "context"
    "log"
    "net/http"
    "os"
    "os/signal"
    "syscall"
    "time"

    "mailer-service-rest/internal/config"
    "mailer-service-rest/internal/http"
    "mailer-service-rest/internal/mailer"
)

func main() {
    cfg := config.Load()

    sender := mailer.New(cfg.SMTPHost, cfg.SMTPPort, cfg.SMTPUser, cfg.SMTPPass)
    handler := httpapi.NewHandler(sender)

    server := &http.Server{
        Addr:    ":8080",
        Handler: handler,
    }

    go func() {
        log.Println("Mailer service (REST) is running on :8080...")
        if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
            log.Fatalf("HTTP server error: %v", err)
        }
    }()

    stop := make(chan os.Signal, 1)
    signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
    <-stop

    log.Println("Shutting down REST mailer service...")

    ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer cancel()

    if err := server.Shutdown(ctx); err != nil {
        log.Fatalf("Shutdown error: %v", err)
    }

    log.Println("Shutdown complete")
}
