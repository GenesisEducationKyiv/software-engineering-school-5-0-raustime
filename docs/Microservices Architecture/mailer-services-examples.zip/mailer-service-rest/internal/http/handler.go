package httpapi

import (
    "encoding/json"
    "log"
    "net/http"

    "mailer-service-rest/internal/mailer"
)

type Handler struct {
    sender *mailer.Sender
}

func NewHandler(sender *mailer.Sender) *Handler {
    return &Handler{sender: sender}
}

type EmailRequest struct {
    To      string `json:"to"`
    Subject string `json:"subject"`
    Body    string `json:"body"`
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost || r.URL.Path != "/send" {
        http.NotFound(w, r)
        return
    }

    var req EmailRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "Invalid request", http.StatusBadRequest)
        return
    }

    if err := h.sender.Send(req.To, req.Subject, req.Body); err != nil {
        log.Printf("send failed: %v", err)
        http.Error(w, "Send failed", http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusOK)
    _, _ = w.Write([]byte(`{"status":"ok"}`))
}
