package config

import (
    "os"
    "strconv"
)

type Config struct {
    NATSURL  string
    SMTPHost string
    SMTPPort int
    SMTPUser string
    SMTPPass string
}

func Load() Config {
    port, _ := strconv.Atoi(os.Getenv("SMTP_PORT"))
    if port == 0 {
        port = 587
    }

    return Config{
        NATSURL:  os.Getenv("NATS_URL"),
        SMTPHost: os.Getenv("SMTP_HOST"),
        SMTPPort: port,
        SMTPUser: os.Getenv("SMTP_USER"),
        SMTPPass: os.Getenv("SMTP_PASS"),
    }
}
