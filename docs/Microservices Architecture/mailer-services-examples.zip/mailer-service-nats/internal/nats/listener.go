package nats

import (
    "encoding/json"
    "log"
    "mailer-service-nats/internal/config"
    "mailer-service-nats/internal/mailer"

    "github.com/nats-io/nats.go"
)

type EmailMessage struct {
    To      string `json:"to"`
    Subject string `json:"subject"`
    Body    string `json:"body"`
}

type Listener struct {
    nc     *nats.Conn
    sender *mailer.Sender
}

func NewListener(cfg config.Config) (*Listener, error) {
    nc, err := nats.Connect(cfg.NATSURL)
    if err != nil {
        return nil, err
    }
    sender := mailer.New(cfg.SMTPHost, cfg.SMTPPort, cfg.SMTPUser, cfg.SMTPPass)
    return &Listener{nc: nc, sender: sender}, nil
}

func (l *Listener) Listen() error {
    _, err := l.nc.Subscribe("mailer.send", func(m *nats.Msg) {
        var msg EmailMessage
        if err := json.Unmarshal(m.Data, &msg); err != nil {
            log.Printf("Invalid message: %v", err)
            return
        }
        log.Printf("Sending email to %s", msg.To)
        if err := l.sender.Send(msg.To, msg.Subject, msg.Body); err != nil {
            log.Printf("Send failed: %v", err)
        }
    })
    return err
}


func (l *Listener) Close(ctx context.Context) error {
    if l.nc != nil && !l.nc.IsClosed() {
        l.nc.Close()
    }
    return nil
}
