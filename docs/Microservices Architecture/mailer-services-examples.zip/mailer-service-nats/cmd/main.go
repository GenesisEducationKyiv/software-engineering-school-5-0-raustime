package main

import (
    "context"
    "log"
    "os"
    "os/signal"
    "syscall"
    "time"

    "mailer-service-nats/internal/config"
    "mailer-service-nats/internal/nats"
)

func main() {
    cfg := config.Load()

    listener, err := nats.NewListener(cfg)
    if err != nil {
        log.Fatalf("failed to start NATS listener: %v", err)
    }

    ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
    defer stop()

    log.Println("Mailer service (NATS) is running...")

    go func() {
        if err := listener.Listen(); err != nil {
            log.Fatalf("listener error: %v", err)
        }
    }()

    <-ctx.Done()
    log.Println("Shutting down...")

    shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer cancel()

    if err := listener.Close(shutdownCtx); err != nil {
        log.Printf("Shutdown error: %v", err)
    } else {
        log.Println("Shutdown complete")
    }
}
