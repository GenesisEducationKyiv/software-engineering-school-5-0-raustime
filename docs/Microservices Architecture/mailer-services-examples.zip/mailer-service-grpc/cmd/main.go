package main

import (
    "context"
    "log"
    "net"
    "os"
    "os/signal"
    "syscall"
    "time"

    "google.golang.org/grpc"
    pb "mailer-service-grpc/proto"
    "mailer-service-grpc/internal/config"
    "mailer-service-grpc/internal/grpcserver"
    "mailer-service-grpc/internal/mailer"
)

func main() {
    cfg := config.Load()

    lis, err := net.Listen("tcp", ":50051")
    if err != nil {
        log.Fatalf("failed to listen: %v", err)
    }

    grpcServer := grpc.NewServer()
    sender := mailer.New(cfg.SMTPHost, cfg.SMTPPort, cfg.SMTPUser, cfg.SMTPPass)
    pb.RegisterMailerServer(grpcServer, grpcserver.NewMailerServer(sender))

    go func() {
        log.Println("Mailer service (gRPC) is running on :50051...")
        if err := grpcServer.Serve(lis); err != nil {
            log.Fatalf("failed to serve: %v", err)
        }
    }()

    stop := make(chan os.Signal, 1)
    signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
    <-stop

    log.Println("Shutting down gRPC server...")

    shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer cancel()

    done := make(chan struct{})
    go func() {
        grpcServer.GracefulStop()
        close(done)
    }()

    select {
    case <-done:
        log.Println("Shutdown complete")
    case <-shutdownCtx.Done():
        log.Println("Shutdown timeout reached")
    }
}
