package grpcserver

import (
    "context"

    pb "mailer-service-grpc/proto"
    "mailer-service-grpc/internal/mailer"
)

type MailerServer struct {
    pb.UnimplementedMailerServer
    sender *mailer.Sender
}

func NewMailerServer(sender *mailer.Sender) *MailerServer {
    return &MailerServer{sender: sender}
}

func (s *MailerServer) SendEmail(ctx context.Context, req *pb.SendEmailRequest) (*pb.SendEmailResponse, error) {
    if err := s.sender.Send(req.To, req.Subject, req.Body); err != nil {
        return nil, err
    }
    return &pb.SendEmailResponse{Status: "ok"}, nil
}
